// SAB FIXME  need to figure out a better way...
// // to get the variant dependency out
#ifndef  _TOKEN_LOCAL_
#define _TOKEN_LOCAL_
#define PK_SW_DIR    "/etc/pkcs11/swtok"

#define PK_DIR     PK_SW_DIR
#define SUB_DIR     "cr"

#define DBGTAG "CR_STDLL_Debug"


#endif
